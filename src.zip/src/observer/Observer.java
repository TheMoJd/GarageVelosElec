package observer;

/**
 * Créez une interface observer.Observer qui sera implémentée par les classes d'observateurs (VueListeVelo et VueVelo).
 * */

public interface Observer {
  void update();
}
