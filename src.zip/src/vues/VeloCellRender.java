package vues;

import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import modele.Velo;
import verification.VerifVelo;

class VeloCellRenderer extends JLabel implements ListCellRenderer<Velo> {
  @Override
  public Component getListCellRendererComponent(JList<? extends Velo> list, Velo velo, int index, boolean isSelected, boolean cellHasFocus) {
    // Utilisez la méthode toString() de Velo pour obtenir la description de base
    String description = velo.toString();

    // Effectuer la vérification de conformité
    String resultatVerif = VerifVelo.verifVelo(velo);
    String statutConformite = resultatVerif.equals("Le vélo est correctement configuré.") ? "<span style='color:green;'>Conforme</span>" : "<span style='color:red;'>Non conforme</span>";

    // Construire la chaîne HTML finale
    String texte =  description + "<br/>Statut: " + statutConformite + "</html>";
    setText(texte);

    // Autres paramètres de rendu (pour la sélection, etc.)
    if (isSelected) {
      setBackground(list.getSelectionBackground());
      setOpaque(true);
    } else {
      setBackground(list.getBackground());
      setOpaque(false);
    }
    setEnabled(list.isEnabled());
    setFont(list.getFont());
    return this;
  }
}
