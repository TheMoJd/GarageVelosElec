package visiteur;

public interface Visitable {
  void accept(Visiteur visiteur);
}
